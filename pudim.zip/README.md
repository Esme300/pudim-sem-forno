# Site estático para Vercel

Este projeto não usa framework, dependências ou build. Na Vercel, importe esta pasta como projeto estático e deixe os campos **Build Command** e **Output Directory** vazios. O arquivo `index.html` está na raiz.
